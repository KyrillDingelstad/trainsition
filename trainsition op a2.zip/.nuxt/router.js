import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1f4f1555 = () => interopDefault(import('..\\pages\\Anticonceptie.vue' /* webpackChunkName: "pages_Anticonceptie" */))
const _4d741a67 = () => interopDefault(import('..\\pages\\Bevalling.vue' /* webpackChunkName: "pages_Bevalling" */))
const _18771253 = () => interopDefault(import('..\\pages\\Contact.vue' /* webpackChunkName: "pages_Contact" */))
const _7351f23c = () => interopDefault(import('..\\pages\\Home.vue' /* webpackChunkName: "pages_Home" */))
const _43e8cc2d = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages_inspire" */))
const _acbb8430 = () => interopDefault(import('..\\pages\\Kraamtijd.vue' /* webpackChunkName: "pages_Kraamtijd" */))
const _9b439838 = () => interopDefault(import('..\\pages\\Nieuws.vue' /* webpackChunkName: "pages_Nieuws" */))
const _6042377f = () => interopDefault(import('..\\pages\\Praktijk.vue' /* webpackChunkName: "pages_Praktijk" */))
const _01d7383d = () => interopDefault(import('..\\pages\\zwanger.vue' /* webpackChunkName: "pages_zwanger" */))
const _58910e36 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/Anticonceptie",
    component: _1f4f1555,
    name: "Anticonceptie"
  }, {
    path: "/Bevalling",
    component: _4d741a67,
    name: "Bevalling"
  }, {
    path: "/Contact",
    component: _18771253,
    name: "Contact"
  }, {
    path: "/Home",
    component: _7351f23c,
    name: "Home"
  }, {
    path: "/inspire",
    component: _43e8cc2d,
    name: "inspire"
  }, {
    path: "/Kraamtijd",
    component: _acbb8430,
    name: "Kraamtijd"
  }, {
    path: "/Nieuws",
    component: _9b439838,
    name: "Nieuws"
  }, {
    path: "/Praktijk",
    component: _6042377f,
    name: "Praktijk"
  }, {
    path: "/zwanger",
    component: _01d7383d,
    name: "zwanger"
  }, {
    path: "/",
    component: _58910e36,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
