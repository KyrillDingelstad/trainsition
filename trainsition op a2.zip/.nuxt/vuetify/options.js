export default {"theme":{"dark":false,"themes":{"light":{"primary":"#0059a6"}}}}
