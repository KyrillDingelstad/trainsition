import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _8459e9fa = () => interopDefault(import('..\\pages\\Anticonceptie.vue' /* webpackChunkName: "pages_Anticonceptie" */))
const _1c7bd1d6 = () => interopDefault(import('..\\pages\\Bevalling.vue' /* webpackChunkName: "pages_Bevalling" */))
const _0fd86281 = () => interopDefault(import('..\\pages\\Contact.vue' /* webpackChunkName: "pages_Contact" */))
const _4fe840ce = () => interopDefault(import('..\\pages\\Home.vue' /* webpackChunkName: "pages_Home" */))
const _3b4a1c5b = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages_inspire" */))
const _4df03a96 = () => interopDefault(import('..\\pages\\Kraamtijd.vue' /* webpackChunkName: "pages_Kraamtijd" */))
const _7ac9b414 = () => interopDefault(import('..\\pages\\Nieuws.vue' /* webpackChunkName: "pages_Nieuws" */))
const _550aed11 = () => interopDefault(import('..\\pages\\Praktijk.vue' /* webpackChunkName: "pages_Praktijk" */))
const _0d8eef2a = () => interopDefault(import('..\\pages\\zwanger.vue' /* webpackChunkName: "pages_zwanger" */))
const _ec2a06da = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/Anticonceptie",
    component: _8459e9fa,
    name: "Anticonceptie"
  }, {
    path: "/Bevalling",
    component: _1c7bd1d6,
    name: "Bevalling"
  }, {
    path: "/Contact",
    component: _0fd86281,
    name: "Contact"
  }, {
    path: "/Home",
    component: _4fe840ce,
    name: "Home"
  }, {
    path: "/inspire",
    component: _3b4a1c5b,
    name: "inspire"
  }, {
    path: "/Kraamtijd",
    component: _4df03a96,
    name: "Kraamtijd"
  }, {
    path: "/Nieuws",
    component: _7ac9b414,
    name: "Nieuws"
  }, {
    path: "/Praktijk",
    component: _550aed11,
    name: "Praktijk"
  }, {
    path: "/zwanger",
    component: _0d8eef2a,
    name: "zwanger"
  }, {
    path: "/",
    component: _ec2a06da,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
