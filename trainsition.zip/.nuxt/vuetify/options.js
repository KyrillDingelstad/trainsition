export default {"theme":{"dark":false,"themes":{"light":{"primary":"#ff34ff"}}}}
