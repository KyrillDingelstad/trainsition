import Vue from 'vue';
import Vuebar from 'vuebar';

Vue.use(Vuebar);